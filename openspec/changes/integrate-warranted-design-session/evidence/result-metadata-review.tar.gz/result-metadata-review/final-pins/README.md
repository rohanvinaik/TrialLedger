# Final three-primitive pin receipt

Scope: `cause_kind`, `completion_code`, and `disposition_code` only. This is a fresh proof directory, separate from the historical pre-review snapshot. The exact reviewed module is retained here; its SHA256 is `42f8c36330d1b10f2f4875191f1b093a0c4fe7bcc62e60b1b75c81ed885b06ed`, byte-identical to production at export. `metadata-identities.json` records whole-file and AST/source digests, interpreter identity, local tool revisions and PYTHONPATH.

| Target | Tool verdict | Value pinning | Function digest |
|---|---|---|---|
| cause_kind | COMPLETE operator universe, modulo one crash-only value gap; 18/18 killed | 17/18 | 2b660e587a3b2e50 |
| completion_code | COMPLETE operator universe; 87/87 killed, line-complete | 87/87 | 0ca68ed2a47b84e6 |
| disposition_code | COMPLETE operator universe; 189/189 killed, line-complete | 189/189 | 721902055853505a |

All three reports confirm isolated reproducibility. The cause mutant replaces the colon separator with an empty separator and raises instead of returning; the report explicitly states it is detected, not equivalent, and nothing is owed to flag. No equivalence flags were added and no authored tests were deleted. Requested distinguishing inputs were supplied for completion and disposition, with initial residual reports preserved unchanged. Every prescribed decomposition ended `DONE: no separable block`; the final survey reported zero static traps and explicitly did not prove unresolved type/input reachability. Completion's parent-authored style LEAVE note is retained in `.detective/judgments.json`; style is separate from behavior certification. Global adapter style suggestions were outside the three-target scope and were not pursued.

The complete fresh proof suite reported **129 passed in 0.26s** (`metadata-proof-suite.log`). Its authored basis includes the 40 existing metadata cases and 73 vocabulary acceptance cases. The copied vocabulary file precedes a format-only edit in production; its executable assertions are unchanged. No production module, shared generated test or shared certificate was edited by this verification task.

`certificates.json` is the untouched tool-generated certificate file containing exactly the three entries, in the existing schema. `generated-tests-manifest.json` contains only the three generated test paths and actual SHA256 values; generated files are copied unchanged under `tests/detective/`. The other manifest covers the complete receipt snapshot. Parent integration must verify these identities before merging into shared paths.

## Explicit contract-checker limit

The explicit CrossHair command used `check` on exactly these three existing contracts with `--report_all`, using the local proof module through PYTHONPATH and a `uv --with crosshair-tool` overlay. `metadata-crosshair.log` reports **Not confirmed** for each contract (source lines 121, 129 and 146). No counterexample was printed; no proof is claimed. Enum-membership contracts are narrower than the authored clinical intent tests.

## Invocation and stopping point

Every temporary process ran through `owned-run`. Detective used the production project's `.venv/bin/detective` interpreter with local Detective, local Wesker and the fresh proof directory on PYTHONPATH. The walk began with full help, then a clean `regime`, then scoped `converge --two-sign`. Full logs and final reports are retained. CrossHair and pytest used the same source snapshot. All scoped chains ended at their named DONE/no-next-action verdicts. There was no adapter-wide mutation campaign, source rewrite, commit or automatic shared certificate merge.
