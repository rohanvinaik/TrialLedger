import pytest

from TrialLedger.layer2 import result_semantics as r

@pytest.mark.parametrize(
    ("code", "expected"),
    [
        ("resource_bound", "computation"),
        ("resource_bound:design_bounds", "computation"),
        ("proposed_refused:reading", "premise"),
        ("open_scope:arm:A", "translation"),
        ("class_membership_unresolved", "evidence"),
        ("no_constraint_mentions_query", "coverage"),
        ("undecided_by_constraints", "constraint"),
        ("signal_conflict:counts", "conflict"),
        ("unknown_future_code", "unclassified"),
        ("", "unclassified"),
    ],
)
def test_named_causes_preserve_unknowns(code, expected):
    assert r.cause_kind(code) == expected

def test_computation_limit_is_never_called_an_evidence_gap():
    assert r.completion_code("UNDETERMINED", ["resource_bound"]) == "limited"
    assert r.completion_code("REFUSED", ["resource_bound:interpretations"]) == "limited"
    assert r.completion_code("UNDETERMINED", ["no_constraint_mentions_query"]) == "complete"

def test_unknown_causes_and_outcomes_do_not_gain_a_complete_label():
    assert r.completion_code("UNDETERMINED", ["future_blocker"]) == "unclassified"
    assert r.completion_code("FUTURE_RESULT", []) == "unclassified"
    assert r.completion_code("UNSUPPORTED_QUERY", []) == "unsupported"
    assert r.completion_code("REFUSED", ["request_not_an_object"]) == "invalid"

def test_open_knowledge_does_not_mean_unfinished_computation():
    assert r.completion_code("unresolved", ["proposed_refused:bridge"]) == "complete"
    assert r.completion_code("abstain", ["rarity_abstained"]) == "complete"

def test_independent_limit_must_not_erase_an_effective_supported_conflict():
    assert r.disposition_code("INCONSISTENT", "known", "limited") == "conflict"
    assert r.disposition_code("refuted", "proposed", "limited") == "conflict"
    assert r.disposition_code("incoherent", "interpolated", "limited") == "conflict"
    assert r.disposition_code("INCONSISTENT", "", "limited") == "unclassified"

def test_conclusive_effective_query_keeps_its_own_support_despite_other_limit():
    assert r.disposition_code("ENTAILED", "known", "limited") == "settled"
    assert r.disposition_code("REFUTED", "interpolated", "limited") == "conditional"
    assert r.disposition_code("ENTAILED", "proposed", "limited") == "conditional"
    assert r.disposition_code("ENTAILED", "", "limited") == "unclassified"

@pytest.mark.parametrize(
    ("result", "standing", "completion", "expected"),
    [
        ("ENTAILED", "known", "complete", "settled"),
        ("REFUTED", "known", "complete", "settled"),
        ("ENTAILED", "interpolated", "complete", "conditional"),
        ("ENTAILED", "proposed", "complete", "conditional"),
        ("ENTAILED", "", "complete", "unclassified"),
        ("UNDETERMINED", "known", "complete", "open"),
        ("UNDETERMINED", "known", "limited", "not_computed"),
        ("INCONSISTENT", "known", "complete", "conflict"),
        ("UNSUPPORTED_QUERY", "known", "unsupported", "unsupported"),
        ("unresolved", "proposed", "complete", "open"),
        ("resolved", "proposed", "complete", "conditional"),
        ("FUTURE", "known", "complete", "unclassified"),
    ],
)
def test_disposition_never_invents_a_design_choice(result, standing, completion, expected):
    assert r.disposition_code(result, standing, completion) == expected
